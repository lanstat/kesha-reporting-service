def money(input):
    if input is not None:
        return '€{:,.2f}'.format(float(input))
    else:
        return '€0.00'

def core__prerender(adapters):
    total = 0
    for r in adapters['_detail']:
        total += float(r[3])
    adapters['_total'] = total
