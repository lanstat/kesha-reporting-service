def core__prerender(adapters):
    adapters['_well'] = 'angra'

def test(input):
    return 'entro ' + str(input)
